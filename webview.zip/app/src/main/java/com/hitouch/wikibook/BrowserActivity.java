package com.hitouch.wikibook;

import java.net.URISyntaxException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class BrowserActivity extends Activity {//manifists의 Activity에서 상속받은 browserActivity
    private final String TAG = "ITouch_WebActivity";
    private WebView mWeb = null;
    private boolean mBackPressed = false;

    //private ImageButton mVoiceBtn;;

    private static final int REQUEST_VOICE = 4;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!checkRestart(savedInstanceState)) {
            //overridePendingTransition(R.anim.anim_right_in, R.anim.anim_stay);

            initLayout();
        }
    }//activity 실행부. initlayout함수 실행됨

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWeb.canGoBack()) {
            mWeb.goBack();
            return true;
        }

        //빽(취소)키가 눌렸을때 종료여부를 묻는 다이얼로그 띄움
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {//keyevent.KEYCODE_BACK : 뒤로가기 키 누를때 보내지는 반응
            AlertDialog.Builder d = new AlertDialog.Builder(this);
            d.setTitle("프로그램을 종료 하시겠습니까?");
            d.setMessage("종료하시려면 '예' 버튼을 눌러주세요.");
            d.setIcon(R.drawable.ic_launcher);
            d.setPositiveButton("아니요", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub
                    //onStop();
                    dialog.cancel();
                }
            });//다이얼로그 버튼 아니오 : 누르면 다이얼로그 캔슬

            d.setNegativeButton("예", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub

                    android.os.Process.killProcess(android.os.Process.myPid());

                    //finish();
                }
            });//다이얼로그 버튼 예 : 누르면 killprocess(종료)됨

            d.show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private boolean checkRestart(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        if (savedInstanceState != null) {
            return true;
        }
        return false;
    }

    public void onBackPressed() {
        if (mWeb.canGoBack()) {
            mWeb.goBack();
        } else {
            super.onBackPressed();
        }
    }//뒤로가기 버튼을 눌렀을때 이전 페이지로 갈수있으면 뒤로 아니라면 다이얼로그 띄움

    public void onDestroy() {
        super.onDestroy();
    }

    private void initLayout() {
        setContentView(R.layout.activity_browser);//xml화면을 보여줌
        setTitle(getString(R.string.title_web_info));//이름 정하기

        mWeb = (WebView) findViewById(com.hitouch.wikibook.R.id.webInfo);//xml의 webview의 id를 mWeb에 넣어 mWeb을 xml의 webview로 칭함
        mWeb.setWebViewClient(new WebClient());
        WebSettings set = mWeb.getSettings();//webview설정
        set.setJavaScriptEnabled(true);//javascript로 설정

        mWeb.getSettings().setDomStorageEnabled(true);
        //여기까지 webview설정부분

        //set.setCacheMode(WebSettings.LOAD_NO_CACHE);

        String url = null;//주소를 담을 변수 초기화

        url = String.format(HttpUrl.WEBURL);//HttpUrl클래스의 WEBURL변수를 가져와서 저장
        mWeb.loadUrl(url);//xml의 webview에 url변수의 주소를 통해서 그 주소의 웹사이트를 띄움
    }

    class WebClient extends WebViewClient {
        @Override
        public void onReceivedSslError(WebView view, final SslErrorHandler handler, SslError error) {
            super.onReceivedSslError(view, handler, error);

            final AlertDialog.Builder builder = new AlertDialog.Builder(BrowserActivity.this);
            String message = getString(R.string.msg_cert_error);

            switch (error.getPrimaryError()) {
                case SslError.SSL_UNTRUSTED:
                    message = getString(R.string.msg_cert_trust_error);
                    break;  // 이 사이트의 보안 인증서는 신뢰할 수 있습니다
                case SslError.SSL_EXPIRED:
                    message = getString(R.string.msg_cert_expired_error);
                    break;  // 보안 인증서가 만료되었습니다.
                case SslError.SSL_IDMISMATCH:
                    message = getString(R.string.msg_cert_mismatched_error);
                    break; // 보안 인증서가 ID 일치하지 않습니다.
                case SslError.SSL_NOTYETVALID:
                    message = getString(R.string.msg_cert_not_yet_error);
                    break;  // 보안 인증서가 아직 유효하지 않습니다.
            }

            handler.proceed();
        }//보안 인증서 체크

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.startsWith("intent:") || url.startsWith("market:") || url.startsWith("ispmobile:")) {
                Intent i;
                try {
                    i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                    return false;
                }

                if (getPackageManager().resolveActivity(i, 0) == null) {
                    String pkgName = i.getPackage();
                    if (pkgName != null) {
                        i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pname:" + pkgName));
                        i.addCategory(Intent.CATEGORY_BROWSABLE);
                        startActivity(i);
                        return true;
                    } else
                        return false;
                }

                try {
                    startActivity(i);
                } catch (Exception e) {

                }

            } else {
                view.loadUrl(url);
                return true;
            }
            return true;
        }
    }

    public void goAnother(View v) {
/*        Intent intent;

        intent = new Intent(this, com.google.zxing.client.android.CaptureActivity.class);
        startActivityForResult(intent, REQUEST_BARCODE);*/
    }

}