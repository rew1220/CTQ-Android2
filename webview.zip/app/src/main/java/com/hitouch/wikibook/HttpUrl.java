package com.hitouch.wikibook;

public class HttpUrl {
    public static final String WEBURL = "http://www.naver.com";
    //webview에 띄울 주소
}
