package com.example.newfileshere1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(new SampleView(this));//xml대신 SampleView 클래스로 view 호출
        setContentView(R.layout.activity_main);//xml사용
    }
}