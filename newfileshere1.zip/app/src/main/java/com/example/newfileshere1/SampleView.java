package com.example.newfileshere1;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class SampleView  extends View {//view로써 작동되는 클래스 Sampleview
    private Bitmap bmp;//이미지를 불러올 수 있는 객체인 Bitmap선언

    private Paint paint = new Paint();//그릴 그림의 설정? 이라고 생각하면 됨
    public SampleView(Context context) {//생성자
        super(context);
        setBackgroundColor(Color.WHITE);//배경 -> 하얀색

        Resources res = getResources();
        bmp = BitmapFactory.decodeResource(res, R.drawable.ic_launcher);//ic_launcher의 리소스를 비트맵으로 가져옴

    }

    @Override
    protected void onDraw(Canvas canvas) {//그리기(쓰기)
        super.onDraw(canvas);
        paint.setTextSize(50);//paint의 글자 사이즈 올리기
        canvas.drawText("Hello World!", 10, 100, paint);//paint에 설정한 값을 토대로 hello world 그리기
        
        canvas.drawBitmap(bmp,0,0,null);//비트맵(사진)그리기
    }
}
